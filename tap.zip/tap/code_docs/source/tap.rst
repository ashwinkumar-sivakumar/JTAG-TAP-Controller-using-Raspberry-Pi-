tap Package
===========

Subpackages
-----------

.. toctree::

    tap.common
    tap.examples
    tap.log
    tap.model
    tap.regression

